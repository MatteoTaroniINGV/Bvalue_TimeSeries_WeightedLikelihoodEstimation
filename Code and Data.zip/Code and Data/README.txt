In this repository we added both codes and data.
Witht the code you can build the b-value time series using the weighted likelihood approach.
This code allows to estimate the alpha parameter and to build the time series using all the events in the selected catalog; 
therefore, the results are different from the one of the paper, where we use half of the catalog for the estimation and
the other half of the catalog to build the b-value time series.


Catalog format: two columns

                 1                                         2
  days from the first event in the catalog       magnitude - magnitude of completeness ( M - M_c )