function [ LambdaOk , weight_N ] = WeightedLikeExp( mY , alpha , Bin )

[cT, ~] = size( mY ) ;       % numer of observations
t = mY( : , 1 ) ;            % vector of the times (from the first event in the catalog)
lambda = zeros( cT-1 , 1 ) ; % preallocation of lambda

for i = 2 : cT
    
    weight    = exp( -alpha.*( t(i) - t(1 : i-1) ) ) ; % weights
    weight_N  = weight./ sum( weight) ;                % normalized weights
    xt        = mY( 1 : i-1 , 2 ) ;                    % magnitudes  
    lambda(i) = 1 / ( sum( xt.*weight_N ) + Bin/2 ) ;  % estimation of lambda
    
end

% final lambda vector (starts from the 2nd observation)
LambdaOk = lambda( 2 : end ) ;