function  [cLogLike , lambda , weight ] = Maximization( mY , alpha , Bin )

[cT, ~] = size(mY); % number of observations

cN = length( alpha ) ;        % length of the vector "alpha"
lambda = zeros( cT-1 , cN ) ; % preallocation of the lambda
weight = zeros( cT-1 , cN ) ; % preallocation of the weights
xt = mY( 2 : end , 2 ) ;      % observations

% loop 'for' for log-likelihood evaluation
for i = 1 : length( alpha )
    
    % weights computation
    [ lambda(:,i) , weight(:,i) ] = WeightedLikeExp( mY , alpha(i) , Bin ) ;
    
    % log-likelihood computation (assuming the exponential distribution)
    cLogLike( i ) = sum( log( lambda(:,i) ) ) - sum( lambda(:,i).* xt ) ;
    
end
