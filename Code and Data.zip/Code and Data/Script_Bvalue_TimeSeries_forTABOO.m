clear all ;  home

%%% load the catalog
Cat = importdata( 'TABOO_ML05_2Col.txt' ) ;

%%% binning of the magnitudes
Binning = 0.01 ;

%%% vector of possible alpha
Alpha = 0 : 0.001 : 0.1 ;


% MLE of alpha
[ LogLike , ~ , ~ ] = Maximization( Cat , Alpha , Binning ) ;

% find the optimum alpha
[ ~ , IndexMax ] = max( LogLike ) ;    
AlphaMax         = Alpha( IndexMax ) ;


%%% plot of the alpha vs log-likelihood
figure(1)
plot( Alpha , LogLike ) 
xlabel( 'Alpha' )
ylabel( 'Log-likelihood' )



%%% loop 'for' to compute the WLE b-values

Nmin = 50 ; % minimum number of observations to compute the b-value;
            % it is important in the first part of the b-value time series

Cont = 1 ; % counter

for i = Nmin + 1 : size( Cat , 1 )
    
    % compute the weights
    weight   = exp( -AlphaMax*( Cat( i , 1 ) - Cat( 1 : i - 1 , 1 ) ) ) ; 
    weight_N = weight./ sum( weight) ; % normalize the weights
    
    % compute the WLE of lambda (exponential distribution)
    LambdaWLE(Cont) = 1/ ( sum( Cat( 1 : i - 1 , 2 ).*weight_N ) + Binning/2 ) ;
    
    % compute the b-value qnd its uncertainty from lambda
    BvalueWLE(Cont) = LambdaWLE(Cont) / log( 10 ) ;
    SigmaWLE(Cont)  = BvalueWLE(Cont)*( sum( weight_N.^2 ) )^( 0.5 ) ;
    
    % update the counter
    Cont = Cont + 1 ;
end



%%% plot of the b-value time series
figure(2)

X = Cat( Nmin + 1 : end , 1 ) - Cat( 1 , 1 ) ; % days from the first event in the catalog
Y1    = BvalueWLE ;
ErrY1 = SigmaWLE ; 

hold on % plot of b-values and the associated uncertainties (+/- sigma)
plot( X , Y1         , 'b'  , 'LineWidth' , 2.5  )
plot( X , Y1 + ErrY1 , 'b' )
plot( X , Y1 - ErrY1 , 'b' )
    
box on % add the labels to the plot
xlim( [ 0 , X(end) ] )
xlabel( 'Time (days)' )
ylabel( 'B-value' )

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%